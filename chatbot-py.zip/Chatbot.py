import Functionschatbot #Imports the function that i have created

print(Functionschatbot.readfile(0))#Here i am using the function that i have imported by giving it a value
name = input(":")
Functionschatbot.writeintofile(name) #Here again i am using the function to insert data into the txt file

print(Functionschatbot.readfile(1))
hhelp = input(":")
Functionschatbot.writeintofile(hhelp)